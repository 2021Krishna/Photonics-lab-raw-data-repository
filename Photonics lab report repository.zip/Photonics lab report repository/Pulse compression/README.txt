The raw data and the Matlab script to obtain the Fig. 4 are in this folder. This folder also includes a schematic diagram of the EO comb pulse compression. 
The input power to the optical samplingscope for the pulse compression measurement was -6.84 dBm.

Files:

		- Schematic diagram: pulse compression.pdf

		- Raw data:	     Pulse measured on an Optical sampling scope (EXFO) of the EO comb without applying spectral phase modulation: EO comb pulse without phase.mat
				     Pulse measured on an Optical sampling scope (EXFO) of the EO comb with applying spectral phase modulation: EO comb pulse with phase dispersion 2 two cycles 0p91psPW.mat	

		- Matlab script to plot the figure: EO_Comb_Pulse_width.m



For the data acquisition we used EXFO optical sampling oscilloscope PSO-102. The compressed pulse (Fourier transfer limited) was obtained by applying a dispersion value of
0.91 ps/nm center at 1549.5 nm

Instructions to obtain the generated figure:

	-  Run 'EO_Comb_Pulse_width.m' file to get the figure included in this folder.

     