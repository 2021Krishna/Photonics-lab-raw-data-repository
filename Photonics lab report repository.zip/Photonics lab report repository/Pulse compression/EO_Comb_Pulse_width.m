%% EO comb pulse width without and with pulse shapping

clear all
clc

file_name = ["EO comb pulse without phase" "EO comb pulse with phase dispersion 2 two cycles 0p91psPW"];

fontname = 'Arial';
figfont = 10;
size1 = [4 4 8 5];
hFig = figure();
set(hFig,'DefaultAxesFontName',fontname,'DefaultTextFontName',fontname,'DefaultAxesFontSize',figfont,'Units','centimeters');
hold on
box on;

for ii = 1:length(file_name)
    
    load(file_name(1,ii));
    
    pulse = power_averaged_ChB;
    pulse = pulse-min(pulse);
    t_vect = time_averaged_ChB;

    plot(t_vect,pulse)
    pulse = pulse(40 < t_vect & t_vect < 80);
    t_vect = t_vect(40 < t_vect & t_vect < 80);

%%  Calculate Full Width Half Maximum (Pulse width)
    halfMax = (min(pulse) + max(pulse)) / 2;
    index1 = find(pulse >= halfMax, 1, 'first');
    index2 = find(pulse >= halfMax, 1, 'last');
    fwhmx = t_vect(index2) - t_vect(index1);

    txt = ['\sigma_t = ' num2str(fwhmx) ' ps'];
    text_width = text(30*ii,0.4,txt,'HorizontalAlignment','center');
    text_width.FontSize = 14;

    xlabel('Time (nm)')
    ylabel('Power (dBm)')
    xlim([0 80])
    
end