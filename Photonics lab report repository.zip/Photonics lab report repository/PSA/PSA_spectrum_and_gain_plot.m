%%  Specturm of Signal/idler and pump plot

clear all
clc

load('PSA without NLF spectrum.mat')

power_no_NLF = power;

figure
hold on
plot(wl,power_no_NLF)

load('PSA with NLF spectrum_4p5pidiv5_phaseatcenter.mat')

power_NLF = power;
power_loss = max(power_no_NLF)-max(power_NLF);

hold on
plot(wl,power_NLF+power_loss)
xlabel('wavelength (nm)')
ylabel('Power (dBm)')

legend(['NLF','No NLF'])

%% PSA Gain plot

load('PSA_gain.mat')
figure
plot(phi,Gain,'-.o')
xlabel('\phi/\pi')
ylabel('Gain')

