The raw data and the Matlab script to obtain Fig. 8(a) and (b) are in this folder. This folder also includes a schematic diagram of the phase sensitive parametric amplification.

Files:

		- Schematic diagram: PSA schematic.pdf

		- Raw data:	     PSA spectrum without NLF: PSA without NLF spectrum.mat
				     PSA spectrum with NLF:    PSA with NLF spectrum_4p5pidiv5_phaseatcenter.mat
				     PSA gain: 		       PSA_gain.mat	

		- Matlab script to plot the figure: PSA_spectrum_and_gain_plot.m



For the data acquisition we used ANDO AQ6317 optical spectrum analyser. Finisar Waveshaper 1000s was used to apply a phase from 0 to 2π at 1548.36 nm signal
with a step of π/10

Instructions to obtain the generated figure:

	-  Run 'PSA_spectrum_and_gain_plot.m' file to get the figures included in this folder.

     