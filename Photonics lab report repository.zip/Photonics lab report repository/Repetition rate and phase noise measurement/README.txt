The raw data and the Matlab script to obtain the Fig. 6 (a) and (b) are in this folder. This folder also includes a schematic diagram of the phase noise measurement of the EO comb.

Files:

		- Schematic diagram: phasenoise_schematic.pdf

		- Raw data:	     Repetition rate of the EO comb: COMB 1KM FIBER RF POWER.csv
				     Phase noise : GROUP1_RFSOURCE_PHASENOISE.csv, COMB PHASE NOISE REP RATE.csv, COMB 1KM FIBER PHASE NOISE 35GA.csv	

		- Matlab script to plot the figure: f_rep_phase_noise.m



For the data acquisition we used an ANritsu MS2840A signal spectrum analyser. 

Instructions to obtain the generated figure:

	-  Run 'f_rep_phase_noise.m' file to get the figures included in this folder.

     