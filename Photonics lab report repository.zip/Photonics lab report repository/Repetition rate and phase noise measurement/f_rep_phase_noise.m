%%  Spectrum analyzer phase noise measurement

clc
clear all

file_name = ["GROUP1_RFSOURCE_PHASENOISE.csv" "COMB PHASE NOISE REP RATE.csv" "COMB 1KM FIBER PHASE NOISE 35GA.csv"];
figure

for ii = 1:length(file_name)
    
    raw_data = csvread(file_name(1,ii),23,0)
    semilogx(raw_data(:,1),raw_data(:,2))
    xlabel('Offset freqeuncy (Hz)')
    ylabel('Phase noise (dBc/Hz)')
    hold on
    
end
legend('RF source','Comb rep.','Comb rep. with 1 km fiber')

%% spectrum analyzer repetition rate of the comb
clc
clear all

raw_data = csvread('COMB 1KM FIBER RF POWER.csv',16,0)

freq = linspace(25049442790,25050442790,length(raw_data))';

figure
hold on
plot(freq*1e-9,raw_data(:,1))
xlabel('RF frequency (GHz)')
ylabel('Power (dBm)')

