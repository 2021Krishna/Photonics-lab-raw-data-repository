The raw data and the Matlab script to obtain the Fig. 2 are in this folder. This folder also includes a schematic diagram of the EO comb generation.

Files:

		- Schematic diagram: EO comb schematic

		- Raw data:	     Spectrum of the CW laser recored on an OSA: 211027_Laser_Res_0p01nm_spectrum.mat
				     Spectrum of the EO comb recored on an OSA: 211027_EO_Comb_Res_0p01nm_spectrum.mat	

		- Matlab script to plot the figures: spectum_plot.m



For the data acquisition we used ANDO AQ6317 optical spectrum analyser (OSA). We set the OSA from 1543 nm to 1556 nm and resolution 0.01 nm.

Instructions to obtain the generated figure:

	-  Run 'spectum_plot.m' file to get the figure included in this folder.

     