%% EO comb and c.w laser spectrum plot

clear all
clc

%%  Figure settings
fontname = 'Arial';
figfont = 10;
size1 = [4 4 8 5];
hFig = figure();
set(hFig,'DefaultAxesFontName',fontname,'DefaultTextFontName',fontname,'DefaultAxesFontSize',figfont,'Units','centimeters');
hold on
box on;

%%  Plot EO comb spectrum
load('211027_EO_Comb_Res_0p01nm_spectrum.mat')      
plot(wl,power)

%%  Plot c.w. laser spectrum
load('211027_Laser_Res_0p01nm_spectrum.mat')
hold on
plot(wl,power)

ylabel('Power (dBm)')
xlabel('Wavelength (nm)')
ylim([-80 0])