This document includes the raw measurement data and Matlab scripts to plot the figures included in the report 'Photonics_lab_report'. It also includes the schematic diagrams in the corresponding folders.
To generate the plots, run the Matlab scripts provided in the corresponding folders.

----------------------
EO comb generation
----------------------
This folder contains the raw data, Matlab code and figures. The raw data files are retrieved from the ANDO AQ6317 optical spectrum analyser (OSA). The matlab file 'specturm_plot.m' reads the raw data files and plot the Figure 2.

Fig. 1
The complete vector graphics version of Figure 1 is included as 'EO comb schematic.pdf'. 
 
Fig. 2
The complete vector graphics version of Figure 2 is included as 'EO comb.pdf'. 


----------------------
Pulse compression
----------------------
The matlab file 'EO_Comb_Pulse_width.m' reads the raw data files and plot the figure inculded in the report.

Fig. 3
The schematic diagram of the EO comb pulse compression is provided in 'pulse compression.pdf'.

Fig. 4
The pulse width of the with and without compression is included in 'pulse width.pdf'.

  
----------------------
Repetition rate and phase noise measurement
----------------------
Fig. 5
The complete vector graphics version of Figure 5 is included as 'phasenoise_schematic.pdf'.

Fig. 6 (a) and (b)
The repetition rate of the EO comb and phase noise measurement of the RF source and the comb is provided in 'phase nosie and sectrum.pdf'


----------------------
PSA
----------------------
Fig. 7
The complete vector graphics version of Figure 7 is included as 'PSA schematic.pdf'.

Fig. 8 (a) and (b)
The PSA spectrum with and without NLF is provided in 'PSA_gain.pdf' at the left and gain in 'PSA_gain.pdf' at the right. 





